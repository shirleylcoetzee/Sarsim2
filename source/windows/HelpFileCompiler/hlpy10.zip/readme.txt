ReadMe for K/oS Helpy 1.0
=========================

To install, simply extract all files in this archive to a directory
and double-click 'INSTALL.DOC'.

INSTALL.DOC contains macros which will install or remove K/oS Helpy
on your computer.


IMPORTANT!
----------
Open Install.DOC and Helpy.DOT with the 'Enable macros'-option of Word
or nothing is working!


Virus-Information
-----------------
Helpy was checked for viruses with F-Prot, McAffee and FWin.


Contact
-------
To contact K/oS please visit us online:
  http://www.kos.hwc.com


1997/06
TeX HeX of K/oS
TeXHeX@msn.com

